package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.EmployeeDao;
import com.example.demo.Entity.Employee;
import com.example.demo.Exception.EmployeeNotFoundException;
import com.example.demo.Exception.SaleryNotFoundException;

import jakarta.transaction.Transactional;
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeDao employeeDaoImpl;
	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
				employeeDaoImpl.save(employee);
				return "saved";
	}

	@Override
	public String updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employeeDaoImpl.save(employee);
		return "updated";
	}

	@Override
	public String deleteEmployee(int employeeId) {
		// TODO Auto-generated method stub
		employeeDaoImpl.deleteById(employeeId);
		return "deleted";
	}

	@Override
	public Employee getEmployeeById(int EmployeeId) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		Optional<Employee> employee= employeeDaoImpl.findById(EmployeeId);
	   if(employee.isPresent()) {
		   return employee.get();
	   }
	   else {
		   throw new EmployeeNotFoundException("Employee Not Found..");
	   }
	}

	@Override
	public List<Employee> getAllemployees() {
		// TODO Auto-generated method stub
		return employeeDaoImpl.findAll();
	}

	@Override
	public List<Employee> getEmployeeSalery(int salery)throws SaleryNotFoundException {
		// TODO Auto-generated method stub
		List<Employee> list= employeeDaoImpl.findBySalery(salery);
		if(list.isEmpty()) {
			throw new SaleryNotFoundException("Salery details Not Found");
		}
		else {
			return list;
		}
	}

	@Override
	public List<Employee> getAllResignation(String resignation) {
		// TODO Auto-generated method stub
		return employeeDaoImpl.findByResignation(resignation);
	}

	
}
