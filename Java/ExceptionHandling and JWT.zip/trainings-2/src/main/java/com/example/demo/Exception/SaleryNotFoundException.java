package com.example.demo.Exception;

public class SaleryNotFoundException extends Exception {
	public SaleryNotFoundException(String message) {
		super(message);
	}
}
