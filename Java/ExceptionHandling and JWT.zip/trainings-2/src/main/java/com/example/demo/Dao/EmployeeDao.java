package com.example.demo.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Employee;

public interface EmployeeDao extends JpaRepository<Employee,Integer>{
	
	public abstract List<Employee> findBySalery(int salery);

	abstract List<Employee> findByResignation(String resignation);
	
}
