package com.example.demo.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.Entity.Employee;
import com.example.demo.Exception.EmployeeNotFoundException;
import com.example.demo.Exception.SaleryNotFoundException;

public interface EmployeeService {

	
abstract String addEmployee(Employee employee);

abstract String updateEmployee(Employee employee);
abstract String deleteEmployee(int employeeId);
abstract Employee getEmployeeById(int employeeId) throws EmployeeNotFoundException;
abstract List<Employee> getAllemployees();
abstract List<Employee> getEmployeeSalery(int salery) throws SaleryNotFoundException;
abstract List<Employee> getAllResignation(String resignation);
}
