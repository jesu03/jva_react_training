package com.example.demo.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

@Entity
public class Employee {
	
	@Id
	@Column(name="eid")
	@GeneratedValue
	private int employeeId;
	@NotEmpty
	@Size(min=6,max=15,message="given in the range")
	private String employeeName;
	@Positive(message="give the positive price")
	private int salery;
	@NotEmpty
	private String resignation;
	public Employee(int employeeId, String employeeName, int salery, String resignation) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salery = salery;
		this.resignation = resignation;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getSalery() {
		return salery;
	}
	public void setSalery(int salery) {
		this.salery = salery;
	}
	public String getResignation() {
		return resignation;
	}
	public void setResignation(String resignation) {
		this.resignation = resignation;
	}
	public Employee() {

	}
	

}
