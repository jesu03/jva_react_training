package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dao.EmployeeDao;
import com.example.demo.Entity.Employee;

import jakarta.transaction.Transactional;
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	EmployeeDao employeeDaoImpl;
	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
				employeeDaoImpl.save(employee);
				return "saved";
	}

	@Override
	public String updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employeeDaoImpl.save(employee);
		return "updated";
	}

	@Override
	public String deleteEmployee(int employeeId) {
		// TODO Auto-generated method stub
		employeeDaoImpl.deleteById(employeeId);
		return "deleted";
	}

	@Override
	public Employee getEmployeeById(int EmployeeId) {
		// TODO Auto-generated method stub
		Optional<Employee> employee= employeeDaoImpl.findById(EmployeeId);
		return employee.get();
	}

	@Override
	public List<Employee> getAllemployees() {
		// TODO Auto-generated method stub
		return employeeDaoImpl.findAll();
	}

	@Override
	public List<Employee> getEmployeeSalery(int salery) {
		// TODO Auto-generated method stub
		return employeeDaoImpl.findBySalery(salery);
	}

	@Override
	public List<Employee> getAllResignation(String resignation) {
		// TODO Auto-generated method stub
		return employeeDaoImpl.findByResignation(resignation);
	}

	
}
