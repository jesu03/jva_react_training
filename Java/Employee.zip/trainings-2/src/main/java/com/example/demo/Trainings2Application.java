package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Trainings2Application {

	public static void main(String[] args) {
		SpringApplication.run(Trainings2Application.class, args);
	}

}
